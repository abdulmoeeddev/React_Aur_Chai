import React from 'react'

function about() {
  return (
    <div>about</div>
  )
}

export default about